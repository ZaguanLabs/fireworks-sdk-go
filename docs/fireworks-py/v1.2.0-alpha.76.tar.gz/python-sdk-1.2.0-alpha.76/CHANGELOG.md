# Changelog

## 1.2.0-alpha.76 (2026-06-04)

Full Changelog: [v1.2.0-alpha.75...v1.2.0-alpha.76](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.75...v1.2.0-alpha.76)

## 1.2.0-alpha.75 (2026-06-03)

Full Changelog: [v1.2.0-alpha.74...v1.2.0-alpha.75](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.74...v1.2.0-alpha.75)

## 1.2.0-alpha.74 (2026-06-01)

Full Changelog: [v1.2.0-alpha.73...v1.2.0-alpha.74](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.73...v1.2.0-alpha.74)

## 1.2.0-alpha.73 (2026-06-01)

Full Changelog: [v1.2.0-alpha.73...v1.2.0-alpha.73](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.73...v1.2.0-alpha.73)

### Bug Fixes
* **training-sdk:** keep forward-only reference trainer single-replica under HSDP (#28043) ([24eef8e](https://github.com/fw-ai-external/python-sdk/commit/24eef8ee7665f84d91b4408a8d56eb1664607e97))

## 1.2.0-alpha.72 (2026-05-21)

Full Changelog: [v1.2.0-alpha.71...v1.2.0-alpha.72](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.71...v1.2.0-alpha.72)

### Chores
* bootstrap public SDK release workflows (#83) ([7dcb03e](https://github.com/fw-ai-external/python-sdk/commit/7dcb03e5380a70b28dd7d438a6e10f55be0e493f))
* bootstrap promotion pipeline workflows (#86) ([e0042ab](https://github.com/fw-ai-external/python-sdk/commit/e0042ab3117a02a7ca5266b4a8400f47627c5402))

## 1.2.0-alpha.71 (2026-05-19)

Full Changelog: [v1.2.0-alpha.70...v1.2.0-alpha.71](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.70...v1.2.0-alpha.71)

## 1.2.0-alpha.70 (2026-05-15)

Full Changelog: [v1.2.0-alpha.69...v1.2.0-alpha.70](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.69...v1.2.0-alpha.70)

## 1.2.0-alpha.69 (2026-05-06)

Full Changelog: [v1.2.0-alpha.68...v1.2.0-alpha.69](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.68...v1.2.0-alpha.69)

### Features

* **sdk/training/hotload:** forward snapshot URI via x-fireworks-hot-load-source-url header ([a842b84](https://github.com/fw-ai-external/python-sdk/commit/a842b8447ef2cddf9c28af5786a5e6cea7477637))

## 1.2.0-alpha.68 (2026-05-06)

Full Changelog: [v1.2.0-alpha.67...v1.2.0-alpha.68](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.67...v1.2.0-alpha.68)

## 1.2.0-alpha.67 (2026-05-05)

Full Changelog: [v1.2.0-alpha.66...v1.2.0-alpha.67](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.66...v1.2.0-alpha.67)

## 1.2.0-alpha.66 (2026-05-01)

Full Changelog: [v1.2.0-alpha.65...v1.2.0-alpha.66](https://github.com/fw-ai-external/python-sdk/compare/v1.2.0-alpha.65...v1.2.0-alpha.66)

### Reverts

* restore prerelease versioning in release-please-config.json ([#132](https://github.com/fw-ai-external/python-sdk/issues/132)) ([a574884](https://github.com/fw-ai-external/python-sdk/commit/a574884c6ad6ffd4c1c2c59590e4e48eb83c9263))

## 1.2.0-alpha.65 (2026-05-01)

Full Changelog: [v1.1.0-alpha.64...v1.2.0-alpha.65](https://github.com/fw-ai-external/python-sdk/compare/v1.1.0-alpha.64...v1.2.0-alpha.65)

### Features

* **sdk/deployment:** SSE-truncation retry hardening ([#129](https://github.com/fw-ai-external/python-sdk/issues/129)) ([fcfdba6](https://github.com/fw-ai-external/python-sdk/commit/fcfdba6c69edbcb412f5ea29d5ac8e2fc034ed13))

## 1.1.0-alpha.64 (2026-04-28)

Full Changelog: [v1.0.1-alpha.63...v1.1.0-alpha.64](https://github.com/fw-ai-external/python-sdk/compare/v1.0.1-alpha.63...v1.1.0-alpha.64)

### Features

* **promote:** accept 4-segment name= kwarg ([#126](https://github.com/fw-ai-external/python-sdk/issues/126)) ([7ecd22f](https://github.com/fw-ai-external/python-sdk/commit/7ecd22f7053a7e877630c80bcbb184248c0adac8))
* support setting headers via env ([59ba573](https://github.com/fw-ai-external/python-sdk/commit/59ba573474c2caf0c95617581a6a34ff6dc37ac4))


### Bug Fixes

* use correct field name format for multipart file arrays ([8aa4a63](https://github.com/fw-ai-external/python-sdk/commit/8aa4a638756d88fce2c1f3becd583cf1b02af343))


### Chores

* **internal:** more robust bootstrap script ([b535ded](https://github.com/fw-ai-external/python-sdk/commit/b535ded71a4e937ccb3462b0a49ce09df7ab42d3))

## 1.0.1-alpha.63 (2026-04-22)

Full Changelog: [v1.0.0-alpha.63...v1.0.1-alpha.63](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.63...v1.0.1-alpha.63)

## 1.0.0-alpha.63 (2026-04-22)

Full Changelog: [v1.0.0-alpha.62...v1.0.0-alpha.63](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.62...v1.0.0-alpha.63)

### Features

* downstream compat shims, CI gates, and test coverage ([#62](https://github.com/fw-ai-external/python-sdk/issues/62)) ([2f59a2f](https://github.com/fw-ai-external/python-sdk/commit/2f59a2f7252441ada6df0d01d3f8cdd2676f21c5))


### Bug Fixes

* **compat:** make acreate(stream=True) iterable without await ([#123](https://github.com/fw-ai-external/python-sdk/issues/123)) ([a8e3121](https://github.com/fw-ai-external/python-sdk/commit/a8e3121e1698df8cba10953c4d3027c996738e48))


### Performance Improvements

* **client:** optimize file structure copying in multipart requests ([da87cc2](https://github.com/fw-ai-external/python-sdk/commit/da87cc2c11620b55f04ad6d3b6bde4e5d2655a92))


### Documentation

* **rollouts:** add BYOT RL rollout guides ([4b9fe46](https://github.com/fw-ai-external/python-sdk/commit/4b9fe4699c808a4d2e379cbc9569b8538a0edeef))

## 1.0.0-alpha.62 (2026-04-16)

Full Changelog: [v1.0.0-alpha.61...v1.0.0-alpha.62](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.61...v1.0.0-alpha.62)

### Bug Fixes

* ensure file data are only sent as 1 parameter ([c7fde6c](https://github.com/fw-ai-external/python-sdk/commit/c7fde6c6eb52390b5389effc08e3644cc23de561))

## 1.0.0-alpha.61 (2026-04-09)

Full Changelog: [v1.0.0-alpha.60...v1.0.0-alpha.61](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.60...v1.0.0-alpha.61)

### Features

* **sdk:** deployment update, delta-chain reset, and stale-error handling for re-attach ([#116](https://github.com/fw-ai-external/python-sdk/issues/116)) ([6d662aa](https://github.com/fw-ai-external/python-sdk/commit/6d662aa5163580768393750787250953e0648e25))
* **training:** add purpose and managed_by fields to TrainerJobConfig ([8b7790c](https://github.com/fw-ai-external/python-sdk/commit/8b7790c9a9113937029227c1b45bb815a63801c4))


### Bug Fixes

* **client:** preserve hardcoded query params when merging with user params ([fc43cb4](https://github.com/fw-ai-external/python-sdk/commit/fc43cb4211d85ff04f245cb2a9998587b949c953))


### Documentation

* **training:** clarify purpose and managed_by are managed-service internal fields ([4e06d9e](https://github.com/fw-ai-external/python-sdk/commit/4e06d9e5a28a3d3975bb02b24f3db94a46cf5f50))
* **training:** make purpose and managed_by docstrings deliberately terse ([defb83d](https://github.com/fw-ai-external/python-sdk/commit/defb83d5c54953a88882b70d37706c4a2749473f))

## 1.0.0-alpha.60 (2026-04-06)

Full Changelog: [v1.0.0-alpha.59...v1.0.0-alpha.60](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.59...v1.0.0-alpha.60)

### Features

* **training-sdk:** add create_base_training_client for LoRA self-reference ([f3fef7c](https://github.com/fw-ai-external/python-sdk/commit/f3fef7c068ee181d587e383c09f2dc00cb926c79))

## 1.0.0-alpha.59 (2026-04-03)

Full Changelog: [v1.0.0-alpha.58...v1.0.0-alpha.59](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.58...v1.0.0-alpha.59)

### Features

* deprecate hot_load_deployment_id with runtime warning ([#105](https://github.com/fw-ai-external/python-sdk/issues/105)) ([e430226](https://github.com/fw-ai-external/python-sdk/commit/e43022693adc701640240488006e4fd4c8f5adbe))

## 1.0.0-alpha.58 (2026-04-03)

Full Changelog: [v1.0.0-alpha.57...v1.0.0-alpha.58](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.57...v1.0.0-alpha.58)

### Bug Fixes

* **training-sdk:** disable delta hotload for LoRA adapters ([#114](https://github.com/fw-ai-external/python-sdk/issues/114)) ([4cfd1e7](https://github.com/fw-ai-external/python-sdk/commit/4cfd1e7b3865802299c52f36c902731672633a4b))

## 1.0.0-alpha.57 (2026-04-03)

Full Changelog: [v1.0.0-alpha.56...v1.0.0-alpha.57](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.56...v1.0.0-alpha.57)

## 1.0.0-alpha.56 (2026-04-03)

Full Changelog: [v1.0.0-alpha.55...v1.0.0-alpha.56](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.55...v1.0.0-alpha.56)

### Features

* add skip_validations to TrainerJobConfig ([#111](https://github.com/fw-ai-external/python-sdk/issues/111)) ([c0498a5](https://github.com/fw-ai-external/python-sdk/commit/c0498a52faa25547e10f33f4aefb7894024bd580))

## 1.0.0-alpha.55 (2026-04-02)

Full Changelog: [v1.0.0-alpha.54...v1.0.0-alpha.55](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.54...v1.0.0-alpha.55)

### Features

* support versioned paths in resolve_training_profile ([#107](https://github.com/fw-ai-external/python-sdk/issues/107)) ([ae77373](https://github.com/fw-ai-external/python-sdk/commit/ae773738d4719f0aa92b3206df3d0d4939e20b98))

## 1.0.0-alpha.54 (2026-04-01)

Full Changelog: [v1.0.0-alpha.53...v1.0.0-alpha.54](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.53...v1.0.0-alpha.54)

### Bug Fixes

* **training-sdk:** close dogfooding gaps for local loops ([#103](https://github.com/fw-ai-external/python-sdk/issues/103)) ([0907345](https://github.com/fw-ai-external/python-sdk/commit/0907345ba8e2389a2fd02fe81cb521de677c119c))

## 1.0.0-alpha.53 (2026-04-01)

Full Changelog: [v1.0.0-alpha.52...v1.0.0-alpha.53](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.52...v1.0.0-alpha.53)

### Bug Fixes

* deployment_shape property returns versioned path ([#102](https://github.com/fw-ai-external/python-sdk/issues/102)) ([74c2c61](https://github.com/fw-ai-external/python-sdk/commit/74c2c61c9b28ec9a03cf5abebfec14f0a1e22baa))

## 1.0.0-alpha.52 (2026-03-30)

Full Changelog: [v1.0.0-alpha.51...v1.0.0-alpha.52](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.51...v1.0.0-alpha.52)

### Features

* add hot_load_trainer_job to DeploymentConfig ([#89](https://github.com/fw-ai-external/python-sdk/issues/89)) ([51d75a3](https://github.com/fw-ai-external/python-sdk/commit/51d75a35c944a1324ba7ec15baef6d827f040ce0))
* use account-level checkpoint promotion endpoint ([#88](https://github.com/fw-ai-external/python-sdk/issues/88)) ([cd9efe9](https://github.com/fw-ai-external/python-sdk/commit/cd9efe90cbc3a262fe8f897e106028a18c0f5ea4))
* use account-level checkpoint promotion endpoint ([#88](https://github.com/fw-ai-external/python-sdk/issues/88)) ([f19ae68](https://github.com/fw-ai-external/python-sdk/commit/f19ae68e478d05d1960027efbfa9a26e9e7a3c3c))


### Bug Fixes

* WeightSyncer.save_dcp passes invalid timeout kwarg to save_state ([#100](https://github.com/fw-ai-external/python-sdk/issues/100)) ([5a1a386](https://github.com/fw-ai-external/python-sdk/commit/5a1a386f82070aaa6ad1e22922260ef55c27b5e6))

## 1.0.0-alpha.51 (2026-03-27)

Full Changelog: [v1.0.0-alpha.50...v1.0.0-alpha.51](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.50...v1.0.0-alpha.51)

### Bug Fixes

* restore missing urlencode import in trainer.py ([#93](https://github.com/fw-ai-external/python-sdk/issues/93)) ([a5b08ba](https://github.com/fw-ai-external/python-sdk/commit/a5b08ba352256218f7cf4c70c83564d7e12639b0))

## 1.0.0-alpha.50 (2026-03-27)

Full Changelog: [v1.0.0-alpha.49...v1.0.0-alpha.50](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.49...v1.0.0-alpha.50)

### Features

* **internal:** implement indices array format for query and form serialization ([0024842](https://github.com/fw-ai-external/python-sdk/commit/00248427c59550e1b5c52e19ab8bdf4589ba57af))
* use account-level checkpoint promotion endpoint ([#88](https://github.com/fw-ai-external/python-sdk/issues/88)) ([7de5386](https://github.com/fw-ai-external/python-sdk/commit/7de538610f2bb0e8b0b2636e7d6d849868b363f2))


### Bug Fixes

* add Pydantic discriminator patch to eliminate ModelInput serialization warnings ([#86](https://github.com/fw-ai-external/python-sdk/issues/86)) ([1ffbf79](https://github.com/fw-ai-external/python-sdk/commit/1ffbf79c36fbbea34505672ef7a514c8a05a2b98))

## 1.0.0-alpha.49 (2026-03-25)

Full Changelog: [v1.0.0-alpha.48...v1.0.0-alpha.49](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.48...v1.0.0-alpha.49)

### Features

* streaming-only inference with adaptive concurrency ([#78](https://github.com/fw-ai-external/python-sdk/issues/78)) ([2440a26](https://github.com/fw-ai-external/python-sdk/commit/2440a26704e396c1d33cdb54db3fa1b695d2c049))


### Chores

* **ci:** skip lint on metadata-only changes ([d08e381](https://github.com/fw-ai-external/python-sdk/commit/d08e381759b76a9423ba812fe08f9163ff9903ed))
* **internal:** update gitignore ([2a9b72d](https://github.com/fw-ai-external/python-sdk/commit/2a9b72d81d2cc9554eb88cb57a8ae5e8ae0a49da))

## 1.0.0-alpha.48 (2026-03-21)

Full Changelog: [v1.0.0-alpha.47...v1.0.0-alpha.48](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.47...v1.0.0-alpha.48)

### Features

* **sdk:** add max_concurrency to DeploymentSampler ([#76](https://github.com/fw-ai-external/python-sdk/issues/76)) ([16ae7a9](https://github.com/fw-ai-external/python-sdk/commit/16ae7a9839bfb878ac806adf3deb488aa3500d30))


### Bug Fixes

* sanitize endpoint path params ([dc696ac](https://github.com/fw-ai-external/python-sdk/commit/dc696ac6039ec141340a3857ce627246f3d48dcc))

## 1.0.0-alpha.47 (2026-03-18)

Full Changelog: [v1.0.0-alpha.46...v1.0.0-alpha.47](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.46...v1.0.0-alpha.47)

### Features

* **sdk:** auto-resolve account_id from API key ([#71](https://github.com/fw-ai-external/python-sdk/issues/71)) ([1ff1e6c](https://github.com/fw-ai-external/python-sdk/commit/1ff1e6c036a5dc532b9f42a44ea2f6e42e64e66a))


### Bug Fixes

* update DOCS_SDK url after training-sdk docs restructure ([#72](https://github.com/fw-ai-external/python-sdk/issues/72)) ([67a198e](https://github.com/fw-ai-external/python-sdk/commit/67a198e6eb64843f08e8b4c8a3f2557ac527c575))

## 1.0.0-alpha.46 (2026-03-17)

Full Changelog: [v1.0.0-alpha.45...v1.0.0-alpha.46](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.45...v1.0.0-alpha.46)

### Features

* **training-sdk:** add promote_checkpoint, strict shape validation, and API key remapping ([#70](https://github.com/fw-ai-external/python-sdk/issues/70)) ([ac86fee](https://github.com/fw-ai-external/python-sdk/commit/ac86fee4fcf93527c1ed173e3bb38a267ac45edf))

## 1.0.0-alpha.45 (2026-03-16)

Full Changelog: [v1.0.0-alpha.44...v1.0.0-alpha.45](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.44...v1.0.0-alpha.45)

### Features

* re-apply GradAccNormalization enum and optim_step override ([#67](https://github.com/fw-ai-external/python-sdk/issues/67)) ([25906a7](https://github.com/fw-ai-external/python-sdk/commit/25906a70e83dcfd8435f3cf3a0bf0904abd2bf9c))


### Bug Fixes

* **deps:** bump minimum typing-extensions version ([49d844c](https://github.com/fw-ai-external/python-sdk/commit/49d844c7fbb1436c733cce45b528b5ac7c19b36f))
* **pydantic:** do not pass `by_alias` unless set ([39e4145](https://github.com/fw-ai-external/python-sdk/commit/39e4145b3ceaeeff945c8805dc3b72392e699e2f))


### Chores

* **internal:** tweak CI branches ([fff0521](https://github.com/fw-ai-external/python-sdk/commit/fff0521a0fc9a3cb4f96ac02557a11b0d363e72b))

## 1.0.0-alpha.44 (2026-03-16)

Full Changelog: [v1.0.0-alpha.43...v1.0.0-alpha.44](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.43...v1.0.0-alpha.44)

## 1.0.0-alpha.43 (2026-03-15)

Full Changelog: [v1.0.0-alpha.42...v1.0.0-alpha.43](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.42...v1.0.0-alpha.43)

### Features

* add grad_accumulation_normalization to optim_step ([#64](https://github.com/fw-ai-external/python-sdk/issues/64)) ([1168a59](https://github.com/fw-ai-external/python-sdk/commit/1168a59d89605c929e1faeb2df3506e3b7ffc204))


### Refactors

* **sdk:** separate shape path and manual path for trainer job config ([#63](https://github.com/fw-ai-external/python-sdk/issues/63)) ([a37e7fd](https://github.com/fw-ai-external/python-sdk/commit/a37e7fdc78ac524bc20395437074b5409350daab))

## 1.0.0-alpha.42 (2026-03-13)

Full Changelog: [v1.0.0-alpha.41...v1.0.0-alpha.42](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.41...v1.0.0-alpha.42)

### Refactors

* **sdk:** async httpx with n=1 completions ([#60](https://github.com/fw-ai-external/python-sdk/issues/60)) ([798f079](https://github.com/fw-ai-external/python-sdk/commit/798f0790bf1a3b1b84523d10c1c9d82b8905f37d))

## 1.0.0-alpha.41 (2026-03-11)

Full Changelog: [v1.0.0-alpha.40...v1.0.0-alpha.41](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.40...v1.0.0-alpha.41)

### Refactors

* **training-sdk:** centralize HTTP transport in _RestClient base class ([#58](https://github.com/fw-ai-external/python-sdk/issues/58)) ([7b4c041](https://github.com/fw-ai-external/python-sdk/commit/7b4c041c8eb70bd616b0b06a0ad8303309ec3ed1))

## 1.0.0-alpha.40 (2026-03-09)

Full Changelog: [v1.0.0-alpha.39...v1.0.0-alpha.40](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.39...v1.0.0-alpha.40)

### Chores

* **training-sdk:** bump tinker to 0.15.0 ([#57](https://github.com/fw-ai-external/python-sdk/issues/57)) ([bc8fd1c](https://github.com/fw-ai-external/python-sdk/commit/bc8fd1c53e7092f40109323b0cac219ec8f2b8cf))

## 1.0.0-alpha.39 (2026-03-09)

Full Changelog: [v1.0.0-alpha.38...v1.0.0-alpha.39](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.38...v1.0.0-alpha.39)

### Refactors

* **training-sdk:** two-path shape override contract ([#56](https://github.com/fw-ai-external/python-sdk/issues/56)) ([8fed2d8](https://github.com/fw-ai-external/python-sdk/commit/8fed2d81c8843f3aa24135cea0bb9f340309d264))

## 1.0.0-alpha.38 (2026-03-08)

Full Changelog: [v1.0.0-alpha.37...v1.0.0-alpha.38](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.37...v1.0.0-alpha.38)

### Bug Fixes

* **trainer:** route via API gateway instead of directRouteHandle ([0d4c142](https://github.com/fw-ai-external/python-sdk/commit/0d4c142aaff78f57a9ac36c5b21400d23f98819d))


### Chores

* **ci:** skip uploading artifacts on stainless-internal branches ([b0c2def](https://github.com/fw-ai-external/python-sdk/commit/b0c2def77734108ffc64036a6b209cd2e3bbdbef))
* update placeholder string ([f7a8b73](https://github.com/fw-ai-external/python-sdk/commit/f7a8b734a0aa9eedc48342c7ab605a22fa079b31))

## 1.0.0-alpha.37 (2026-03-07)

Full Changelog: [v1.0.0-alpha.36...v1.0.0-alpha.37](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.36...v1.0.0-alpha.37)

### Bug Fixes

* **sdk:** apply_shape always autofills from training shape values ([#52](https://github.com/fw-ai-external/python-sdk/issues/52)) ([0d32bb4](https://github.com/fw-ai-external/python-sdk/commit/0d32bb4834a718384ed6038a389dc3691a8b0c83))
* **sdk:** update error messages with current URLs and Discord support ([#51](https://github.com/fw-ai-external/python-sdk/issues/51)) ([81ed6e1](https://github.com/fw-ai-external/python-sdk/commit/81ed6e183c04f8a3b74926478b7e545557fa7bd4))


### Refactors

* **types:** use `extra_items` from PEP 728 ([2a492a9](https://github.com/fw-ai-external/python-sdk/commit/2a492a98e66352c7107c125775ea43cb486db08d))

## 1.0.0-alpha.36 (2026-03-04)

Full Changelog: [v1.0.0-alpha.35...v1.0.0-alpha.36](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.35...v1.0.0-alpha.36)

### Features

* training shape apply_shape, tinker pin, and README cleanup ([#49](https://github.com/fw-ai-external/python-sdk/issues/49)) ([45ce71c](https://github.com/fw-ai-external/python-sdk/commit/45ce71ceb61f500f4d62522dc066dd2c9a69c503))


### Styles

* fix import sorting in trainer and test_trainer ([#50](https://github.com/fw-ai-external/python-sdk/issues/50)) ([7156fbb](https://github.com/fw-ai-external/python-sdk/commit/7156fbb33021044ed7f97ab0436b07b838c6ab51))

## 1.0.0-alpha.35 (2026-03-03)

Full Changelog: [v1.0.0-alpha.34...v1.0.0-alpha.35](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.34...v1.0.0-alpha.35)

### Bug Fixes

* make training extras publishable on PyPI ([#48](https://github.com/fw-ai-external/python-sdk/issues/48)) ([c1478f9](https://github.com/fw-ai-external/python-sdk/commit/c1478f97437fcee568aece00599ec12f9232fefb))

## 1.0.0-alpha.34 (2026-03-03)

Full Changelog: [v1.0.0-alpha.33...v1.0.0-alpha.34](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.33...v1.0.0-alpha.34)

### Refactors

* move training cookbook out of the SDK repo ([#47](https://github.com/fw-ai-external/python-sdk/issues/47)) ([ceb5d6c](https://github.com/fw-ai-external/python-sdk/commit/ceb5d6cdff5a9b6e4777f0a58a19b694fd00b968))

## 1.0.0-alpha.33 (2026-03-03)

Full Changelog: [v1.0.0-alpha.32...v1.0.0-alpha.33](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.32...v1.0.0-alpha.33)

### Bug Fixes

* on-policy sampling and disable speculative decoding for hotload ([#46](https://github.com/fw-ai-external/python-sdk/issues/46)) ([2fb012b](https://github.com/fw-ai-external/python-sdk/commit/2fb012b64bccc122680b98b3108923dfff4a93b4))

## 1.0.0-alpha.32 (2026-03-03)

Full Changelog: [v1.0.0-alpha.31...v1.0.0-alpha.32](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.31...v1.0.0-alpha.32)

### Bug Fixes

* proper forward_only shape resolution and separate ref training shape support ([#45](https://github.com/fw-ai-external/python-sdk/issues/45)) ([6de7555](https://github.com/fw-ai-external/python-sdk/commit/6de7555712885397ef6363610b624ddbfd95b823))

## 1.0.0-alpha.31 (2026-03-03)

Full Changelog: [v1.0.0-alpha.30...v1.0.0-alpha.31](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.30...v1.0.0-alpha.31)

### Bug Fixes

* wire CISPO into policy_loss dispatch and Config ([#44](https://github.com/fw-ai-external/python-sdk/issues/44)) ([062c220](https://github.com/fw-ai-external/python-sdk/commit/062c22024054f1c98aba7e6a7675ffe7ee9d1a2c))


### Documentation

* update training READMEs for new RL features and streaming loop ([#43](https://github.com/fw-ai-external/python-sdk/issues/43)) ([678682e](https://github.com/fw-ai-external/python-sdk/commit/678682ea4c9868903c6179ca70cf54545816e978))

## 1.0.0-alpha.30 (2026-03-02)

Full Changelog: [v1.0.0-alpha.29...v1.0.0-alpha.30](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.29...v1.0.0-alpha.30)

### Bug Fixes

* keep GRPO router replay policy-only ([353b45e](https://github.com/fw-ai-external/python-sdk/commit/353b45eeb6ca697af0ff454716a52f9062892896))
* Optimize metrics, batch forward, configurable timeout ([#41](https://github.com/fw-ai-external/python-sdk/issues/41)) ([4d754c8](https://github.com/fw-ai-external/python-sdk/commit/4d754c8f0381e66e0c7a0cdfafc12572d3fa5918))
* remove duplicate GRPO reference forward call ([6af3b03](https://github.com/fw-ai-external/python-sdk/commit/6af3b038ae654bde9608fd5fa6dee024dfdeace2))

## 1.0.0-alpha.29 (2026-02-26)

Full Changelog: [v1.0.0-alpha.28...v1.0.0-alpha.29](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.28...v1.0.0-alpha.29)

### Features

* add client-side max seq length filter and align defaults ([cbac95f](https://github.com/fw-ai-external/python-sdk/commit/cbac95ff8d2b1a1b8776b0ddb6ca0107460c063b))
* training shape auto-config, DAPO/GSPO losses, deployment readiness probing ([4d1f333](https://github.com/fw-ai-external/python-sdk/commit/4d1f3337b9c8da3f46e9a6fb3318188b004955a3))


### Bug Fixes

* align DAPO/GSPO loss behavior with reference implementations ([4f65e1e](https://github.com/fw-ai-external/python-sdk/commit/4f65e1e3dbc3d6837204c7066a1bbd95be9dc6b6))
* align TIS with slime -- add icepop, safe ratio, default clip=2.0 ([2acdcc3](https://github.com/fw-ai-external/python-sdk/commit/2acdcc3a3e19752ae5de7eb300d0f153d5521a33))
* clarify weight sync variable naming in cookbook recipes ([f213b88](https://github.com/fw-ai-external/python-sdk/commit/f213b889d70ffc7c1b9258f6e592243ec5a56633))
* orthogonal TIS, deployment parallelization, stale CISPO refs ([0a90ecb](https://github.com/fw-ai-external/python-sdk/commit/0a90ecb24974711e8905034a693ad073f9bf149e))
* pass return_dict=False to apply_chat_template for transformers&gt;=5 compat ([5a660aa](https://github.com/fw-ai-external/python-sdk/commit/5a660aa65933e0b7e3efd109a627679318c0542f))
* resolve pyright lint errors in train_sft.py ([586f1c1](https://github.com/fw-ai-external/python-sdk/commit/586f1c1262ef0f1b3e9b075254fa1a32501e07a3))
* return_dict compatibility, training shape error messages, GSPO PPO clipping ([928a09e](https://github.com/fw-ai-external/python-sdk/commit/928a09ee4203dac42f903c0961eed2c20b259831))
* skip shape-derived fields in trainer API when using training shapes ([72e0bcc](https://github.com/fw-ai-external/python-sdk/commit/72e0bccb7642878ea004f1770a86684f2beb4a2c))
* sort imports to pass ruff I001 lint ([0d3d8ec](https://github.com/fw-ai-external/python-sdk/commit/0d3d8ec08584dfc24f39b507b5edc77b3acd3716))
* trim redundant and over-mocked tests ([df3060e](https://github.com/fw-ai-external/python-sdk/commit/df3060e7d6807ec50874dc2bcb669361dc00eb2e))


### Chores

* **internal:** make `test_proxy_environment_variables` more resilient to env ([6de8f74](https://github.com/fw-ai-external/python-sdk/commit/6de8f74802069b6323d670835955bcdaae92a009))


### Refactors

* simplify TIS to vanilla implementation with safety clamp ([7f2d7f1](https://github.com/fw-ai-external/python-sdk/commit/7f2d7f1342c18c2f3e5043698b8c657121e1e7df))

## 1.0.0-alpha.28 (2026-02-23)

Full Changelog: [v1.0.0-alpha.27...v1.0.0-alpha.28](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.27...v1.0.0-alpha.28)

### Features

* add R3 routing matrix side-channel injection for official tinker compat ([f6b637b](https://github.com/fw-ai-external/python-sdk/commit/f6b637bd66a94501e7ff66ed671e2a8ff30f752a))
* default prompt_cache_max_len=0 to disable KV cache for verification ([e49ecfb](https://github.com/fw-ai-external/python-sdk/commit/e49ecfbf303eb27c41f69fb19728f8b44843a91c))
* default to greedy mode, add --stochastic flag, include dataset ([049c4e9](https://github.com/fw-ai-external/python-sdk/commit/049c4e9c8d187cb5459b55563b7e66a78fd8a3bc))
* port firetitan SDK and cookbook into fireworks.training ([7134d64](https://github.com/fw-ai-external/python-sdk/commit/7134d649fbd51e3c0bd2cfecadc27bd029f92df7))
* port SDK unit tests from train-firetitan-py ([dac3472](https://github.com/fw-ai-external/python-sdk/commit/dac347290670965c2878179ce2ffe55ff2060c87))
* Regenerate API Reference / Docs ([d97cb7a](https://github.com/fw-ai-external/python-sdk/commit/d97cb7ab0081236ff6bfa342c62943ad79499261))
* Regenerate OpenAPI specs and SDK (v4.24.80) ([ea622fd](https://github.com/fw-ai-external/python-sdk/commit/ea622fd7788900720de1990178b50d34c3da32b9))
* Service mode LoRA documentation ([32edbcd](https://github.com/fw-ai-external/python-sdk/commit/32edbcd89311e2c71acec9a1f795731dcd8eef48))


### Bug Fixes

* correct stale "Server tokenization" log label to "Client tokenization" ([5e6fdcc](https://github.com/fw-ai-external/python-sdk/commit/5e6fdccf57e080db5ef4ccd7990048967ead96b5))
* exclude examples from mypy to avoid duplicate module conflict ([c2ca3e5](https://github.com/fw-ai-external/python-sdk/commit/c2ca3e5d4f800872c5786d6f890ea0715ae73163))
* harden client-side tokenization migration ([7c586fd](https://github.com/fw-ai-external/python-sdk/commit/7c586fd4e0f0269914f7781b85faf2d394ee308f))
* **internal:** skip tests that depend on mock server ([2aa4aca](https://github.com/fw-ai-external/python-sdk/commit/2aa4acae0a3e58ca77eba14aff8ea0834948d29e))
* move reportCallIssue ignore to weight_decay line ([8146334](https://github.com/fw-ai-external/python-sdk/commit/8146334b9268a95afd1e262c9e87f4534731cb58))
* pass trust_remote_code=True to AutoTokenizer.from_pretrained ([7ae2b5d](https://github.com/fw-ai-external/python-sdk/commit/7ae2b5dc01525e09788d017a2e23ba986b58834e))
* remove sdk/cookbook from training __all__ to fix pyright error ([d185f6f](https://github.com/fw-ai-external/python-sdk/commit/d185f6f22461970e438e0008ee1b392de4ddd841))
* resolve all ruff lint errors in ported SDK/cookbook code ([5df914d](https://github.com/fw-ai-external/python-sdk/commit/5df914d85953cbfdfa0163fd7e5a7b3257852f2a))
* resolve e2e test issues found during test runs ([ed2ed28](https://github.com/fw-ai-external/python-sdk/commit/ed2ed286a2d7d6e0d87225fccaab81fdcb47af4d))
* resolve pyright lint errors in training examples ([13f97fd](https://github.com/fw-ai-external/python-sdk/commit/13f97fd2f0824b27cd902678866b37d0f3eef2a8))
* suppress tinker SDK type stub errors in training examples ([41ab1d6](https://github.com/fw-ai-external/python-sdk/commit/41ab1d67e89b5b7ba6fe80ee1cdd86d38b74b4f9))
* use proper type annotation for __all__ to satisfy pyright and ruff ([71fb6bc](https://github.com/fw-ai-external/python-sdk/commit/71fb6bcd61b111e86396385fbc4916a72016958b))


### Chores

* **internal:** add request options to SSE classes ([91db2ea](https://github.com/fw-ai-external/python-sdk/commit/91db2ea0443a121b8db29f8bd951912cb3d78241))
* **internal:** make `test_proxy_environment_variables` more resilient ([6b909f0](https://github.com/fw-ai-external/python-sdk/commit/6b909f0255d1c49947d030ec1470637010f06190))
* **internal:** remove bad test ([4ad6fcf](https://github.com/fw-ai-external/python-sdk/commit/4ad6fcf7dfb730be13593e36ac7e793ecc79902d))
* **internal:** remove mock server code ([fbb2657](https://github.com/fw-ai-external/python-sdk/commit/fbb2657dc23c85bf6d472fd7ed08770fc68330db))
* move verify_logprobs.py and watch_trainer_pods.sh to fireworks repo ([ae3cf92](https://github.com/fw-ai-external/python-sdk/commit/ae3cf92b09d2fa31e5702f995c59c39a4a1039ad))
* remove --stochastic flag, keep greedy as the only default ([5502945](https://github.com/fw-ai-external/python-sdk/commit/5502945d3a8fdc23ea9b5d1b099e15e207a03881))
* remove redundant tinker_patch.py ([27b5521](https://github.com/fw-ai-external/python-sdk/commit/27b55213de1a65f07239c04a7068d455e6d38290))
* sanitize training code for public release ([36fc2ba](https://github.com/fw-ai-external/python-sdk/commit/36fc2ba78413facbccc1c208e3786ef7966c7e67))
* sanitize training docs/tests for public release ([ee1fdb7](https://github.com/fw-ai-external/python-sdk/commit/ee1fdb7076d6c43c4b3146e9cf42a8455a123fae))
* update mock server docs ([db18242](https://github.com/fw-ai-external/python-sdk/commit/db182427328916d87802bd1ba87b5415a9f963d7))


### Documentation

* add compact training readmes and fix lint imports ([12d7196](https://github.com/fw-ai-external/python-sdk/commit/12d7196247c46d6fec79a29811628ec6322e8719))


### Refactors

* clean up verify_logprobs and move to cookbook ([042c731](https://github.com/fw-ai-external/python-sdk/commit/042c731f574e2aa326952a9e744af60d640bbfa1))
* replace R3 side-channel with ModelInput monkey-patch ([53bed56](https://github.com/fw-ai-external/python-sdk/commit/53bed56f8e14e712bdd0e9c1a0d01935fcd5baee))

## 1.0.0-alpha.27 (2026-02-12)

Full Changelog: [v1.0.0-alpha.26...v1.0.0-alpha.27](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.26...v1.0.0-alpha.27)

### Features

* Add Anthropic-compatible Messages API documentation ([f696fa5](https://github.com/fw-ai-external/python-sdk/commit/f696fa543034ff2aacef3796660c69149ab42c55))
* Regenerate OpenAPI specs to add awsS3Config to DPO jobs ([432872b](https://github.com/fw-ai-external/python-sdk/commit/432872b62366b943a49b41298d44e669d4035525))


### Chores

* format all `api.md` files ([41f570a](https://github.com/fw-ai-external/python-sdk/commit/41f570afba601f67136aadcf36f526abee3f0ae1))
* **internal:** bump dependencies ([aa63566](https://github.com/fw-ai-external/python-sdk/commit/aa6356683cc2fdb6e24f0acf710d44d32007f2f4))
* **internal:** fix lint error on Python 3.14 ([9f67e71](https://github.com/fw-ai-external/python-sdk/commit/9f67e7107cfef0c10984ea1bad0fb67d03e62288))

## 1.0.0-alpha.26 (2026-01-30)

Full Changelog: [v1.0.0-alpha.25...v1.0.0-alpha.26](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.25...v1.0.0-alpha.26)

### Features

* **client:** add custom JSON encoder for extended type support ([38fabde](https://github.com/fw-ai-external/python-sdk/commit/38fabde3f36a5d7eb776eadea985db488cff586a))
* update API reference / SDK ([127a473](https://github.com/fw-ai-external/python-sdk/commit/127a4730a682feffa241cf8a63bbce6e436c6e21))

## 1.0.0-alpha.25 (2026-01-27)

Full Changelog: [v1.0.0-alpha.24...v1.0.0-alpha.25](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.24...v1.0.0-alpha.25)

### Features

* update API reference ([9f7626c](https://github.com/fw-ai-external/python-sdk/commit/9f7626cb71374ec9c44d3f1de7ee44c22dd91126))

## 1.0.0-alpha.24 (2026-01-23)

Full Changelog: [v1.0.0-alpha.23...v1.0.0-alpha.24](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.23...v1.0.0-alpha.24)

### Chores

* **ci:** upgrade `actions/github-script` ([7869665](https://github.com/fw-ai-external/python-sdk/commit/7869665ddc977126a2bd375a046538b9b6cb66b5))

## 1.0.0-alpha.23 (2026-01-16)

Full Changelog: [v1.0.0-alpha.22...v1.0.0-alpha.23](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.22...v1.0.0-alpha.23)

### Features

* **validation:** add Pydantic models and validation for dataset rows in training workflow ([a4cbe9b](https://github.com/fw-ai-external/python-sdk/commit/a4cbe9b7d1eec031116d9960b21385071f5a6093))


### Chores

* **internal:** update `actions/checkout` version ([14881d2](https://github.com/fw-ai-external/python-sdk/commit/14881d22e04ec739d2ee20a9757dbeb9d1d84079))

## 1.0.0-alpha.22 (2026-01-13)

Full Changelog: [v1.0.0-alpha.21...v1.0.0-alpha.22](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.21...v1.0.0-alpha.22)

### Features

* Add model_kind and model_state schemas to stainless.yml ([67e6a8b](https://github.com/fw-ai-external/python-sdk/commit/67e6a8b67942c7be36a78a9308b725b137083c94))
* **client:** add support for binary request streaming ([d9e22fd](https://github.com/fw-ai-external/python-sdk/commit/d9e22fd467aeabe9fb6243353d74a5de5a5e33ad))


### Chores

* **internal:** codegen related update ([7fbd701](https://github.com/fw-ai-external/python-sdk/commit/7fbd701b46f7bc446bd295da4628e415e5f2e19c))

## 1.0.0-alpha.21 (2026-01-12)

Full Changelog: [v1.0.0-alpha.20...v1.0.0-alpha.21](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.20...v1.0.0-alpha.21)

### Features

* Regenerate SDK Docs ([5072494](https://github.com/fw-ai-external/python-sdk/commit/5072494385b4c5862aa3d281fe50a801ef3f4003))


### Chores

* **internal:** codegen related update ([5857d3e](https://github.com/fw-ai-external/python-sdk/commit/5857d3e64487426fc42c645e20099cdd83868b42))

## 1.0.0-alpha.20 (2025-12-23)

Full Changelog: [v1.0.0-alpha.19...v1.0.0-alpha.20](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.19...v1.0.0-alpha.20)

### Features

* Remove deprecated Evaluator fields ([be410eb](https://github.com/fw-ai-external/python-sdk/commit/be410ebe0b291ba2c726d0c716776d8d4da17f87))

## 1.0.0-alpha.19 (2025-12-22)

Full Changelog: [v1.0.0-alpha.18...v1.0.0-alpha.19](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.18...v1.0.0-alpha.19)

### Features

* Document GLM 4.7 / reasoning_history ([a7e17a6](https://github.com/fw-ai-external/python-sdk/commit/a7e17a6cde8649814d3bcacedcc6e175d1671116))

## 1.0.0-alpha.18 (2025-12-20)

Full Changelog: [v1.0.0-alpha.17...v1.0.0-alpha.18](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.17...v1.0.0-alpha.18)

## 1.0.0-alpha.17 (2025-12-20)

Full Changelog: [v1.0.0-alpha.16...v1.0.0-alpha.17](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.16...v1.0.0-alpha.17)

## 1.0.0-alpha.16 (2025-12-19)

Full Changelog: [v1.0.0-alpha.15...v1.0.0-alpha.16](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.15...v1.0.0-alpha.16)

### Features

* Add deployment shapes to sdk ([5156da6](https://github.com/fw-ai-external/python-sdk/commit/5156da6ed9bfaf6e58d2275480f2dd7dd7aaa9ce))

## 1.0.0-alpha.15 (2025-12-19)

Full Changelog: [v1.0.0-alpha.14...v1.0.0-alpha.15](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.14...v1.0.0-alpha.15)

### Features

* run "make" + add SDK generation guide ([10b9806](https://github.com/fw-ai-external/python-sdk/commit/10b9806dfd4efa78416b3443bb75b83cfd58f3e9))

## 1.0.0-alpha.14 (2025-12-19)

Full Changelog: [v1.0.0-alpha.13...v1.0.0-alpha.14](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.13...v1.0.0-alpha.14)

### Documentation

* add more examples ([b3b223c](https://github.com/fw-ai-external/python-sdk/commit/b3b223ce01c829f401b20902247962ee1de0de76))

## 1.0.0-alpha.13 (2025-12-18)

Full Changelog: [v1.0.0-alpha.12...v1.0.0-alpha.13](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.12...v1.0.0-alpha.13)

### Features

* Updated `stainless.yml` to include execute train step ([617aaf9](https://github.com/fw-ai-external/python-sdk/commit/617aaf92a5bc0acf43d7ec9a883409d248ff8d36))


### Chores

* **internal:** add `--fix` argument to lint script ([859cb4f](https://github.com/fw-ai-external/python-sdk/commit/859cb4f846f0d5f975df3eaa9d018457491fc0b9))

## 1.0.0-alpha.12 (2025-12-17)

Full Changelog: [v1.0.0-alpha.11...v1.0.0-alpha.12](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.11...v1.0.0-alpha.12)

### Bug Fixes

* use async_to_httpx_files in patch method ([5759d42](https://github.com/fw-ai-external/python-sdk/commit/5759d426884811343b4c50c67c8bde0481af9045))

## 1.0.0-alpha.11 (2025-12-16)

Full Changelog: [v1.0.0-alpha.10...v1.0.0-alpha.11](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.10...v1.0.0-alpha.11)

### Chores

* speedup initial import ([2736393](https://github.com/fw-ai-external/python-sdk/commit/2736393d2907825b2cf67e5f139753894663f77f))

## 1.0.0-alpha.10 (2025-12-16)

Full Changelog: [v1.0.0-alpha.9...v1.0.0-alpha.10](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.9...v1.0.0-alpha.10)

### Features

* Expose Create Evaluator method as part of Docs/SDK ([050063d](https://github.com/fw-ai-external/python-sdk/commit/050063d763bba40cd229f555e6f6bc22e8a0b7d8))


### Chores

* **internal:** add missing files argument to base client ([bcf1a7a](https://github.com/fw-ai-external/python-sdk/commit/bcf1a7a50280d5c7e3ec5492f6770b10e83526ca))

## 1.0.0-alpha.9 (2025-12-12)

Full Changelog: [v1.0.0-alpha.8...v1.0.0-alpha.9](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.8...v1.0.0-alpha.9)

## 1.0.0-alpha.8 (2025-12-12)

Full Changelog: [v1.0.0-alpha.7...v1.0.0-alpha.8](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.7...v1.0.0-alpha.8)

### Features

* add pagination ([d2ab4bc](https://github.com/fw-ai-external/python-sdk/commit/d2ab4bc3171b3ac6ae70207df83793b9dc90c49e))
* Automate SDK Pagination Config ([d098f72](https://github.com/fw-ai-external/python-sdk/commit/d098f72fc6f2099e627eb647a62770a76aadc7de))

## 1.0.0-alpha.7 (2025-12-10)

Full Changelog: [v1.0.0-alpha.6...v1.0.0-alpha.7](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.6...v1.0.0-alpha.7)

### Features

* Remove methods from SDK ([2d73091](https://github.com/fw-ai-external/python-sdk/commit/2d730913dbc2c1f05547d891256d62f5d9067015))

## 1.0.0-alpha.6 (2025-12-10)

Full Changelog: [v1.0.0-alpha.5...v1.0.0-alpha.6](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.5...v1.0.0-alpha.6)

### Features

* add evaluator job / evaluator CRUD APIs to API/SDK ([1f677b8](https://github.com/fw-ai-external/python-sdk/commit/1f677b87c8330c0c0e1d768319c15fbce5930f5d))

## 1.0.0-alpha.5 (2025-12-09)

Full Changelog: [v1.0.0-alpha.4...v1.0.0-alpha.5](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.4...v1.0.0-alpha.5)

### Features

* Update API/SDK ([c47e0fb](https://github.com/fw-ai-external/python-sdk/commit/c47e0fb7a18a05fd4c50d46bf024762f7c83ff00))


### Bug Fixes

* **types:** allow pyright to infer TypedDict types within SequenceNotStr ([211cefd](https://github.com/fw-ai-external/python-sdk/commit/211cefd338e16d81c8a40a1acf9e3399a0ebfbd0))


### Chores

* add missing docstrings ([ac5bf0c](https://github.com/fw-ai-external/python-sdk/commit/ac5bf0c1229ded12db30d75bffa3540c69280785))
* **docs:** use environment variables for authentication in code snippets ([1501b2f](https://github.com/fw-ai-external/python-sdk/commit/1501b2fc7f1320a1d4a41fc39e6fdb0bc4d795c6))
* update lockfile ([58d2c86](https://github.com/fw-ai-external/python-sdk/commit/58d2c86e5856bbc1f3550b6449502a5b302e5c6e))

## 1.0.0-alpha.4 (2025-12-03)

Full Changelog: [v1.0.0-alpha.3...v1.0.0-alpha.4](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.3...v1.0.0-alpha.4)

### Bug Fixes

* type errors in example file ([b707bb8](https://github.com/fw-ai-external/python-sdk/commit/b707bb818e8f05d01fa984f9f55a3fc3dd0d6498))


### Chores

* remove external reference comments from example file ([6538f6a](https://github.com/fw-ai-external/python-sdk/commit/6538f6a62fbec221dc35743220bf77bd0f86ab3c))


### Documentation

* add iterative reinforcement learning workflow example ([56850d7](https://github.com/fw-ai-external/python-sdk/commit/56850d7e7cf0bc813538c01c4d8243726ac6330f))

## 1.0.0-alpha.3 (2025-12-02)

Full Changelog: [v1.0.0-alpha.2...v1.0.0-alpha.3](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.2...v1.0.0-alpha.3)

### Features

* try send_as_path ([1c7ed63](https://github.com/fw-ai-external/python-sdk/commit/1c7ed63dac60bb88d70148e0142c496ff1c409c1))


### Documentation

* add account_id configuration section and update examples ([f1ca3af](https://github.com/fw-ai-external/python-sdk/commit/f1ca3af4a1f388a841cc36defdc780560f4d7587))

## 1.0.0-alpha.2 (2025-12-02)

Full Changelog: [v1.0.0-alpha.1...v1.0.0-alpha.2](https://github.com/fw-ai-external/python-sdk/compare/v1.0.0-alpha.1...v1.0.0-alpha.2)

### Documentation

* add dataset upload documentation with complete workflow examples ([821046d](https://github.com/fw-ai-external/python-sdk/commit/821046dc40cf1c9bf4c468bf5dd2ed02e21f6188))
* add link to Fireworks Dashboard for viewing datasets ([d69db06](https://github.com/fw-ai-external/python-sdk/commit/d69db060892d2f151e13316597d5fcb7afda5c75))
* improve examples to print meaningful response content ([f801de8](https://github.com/fw-ai-external/python-sdk/commit/f801de8187ef6a41136a3df23e1955bae1595d65))

## 1.0.0-alpha.1 (2025-12-02)

Full Changelog: [v0.0.1...v1.0.0-alpha.1](https://github.com/fw-ai-external/python-sdk/compare/v0.0.1...v1.0.0-alpha.1)

### Features

* Add documentation about streaming usage in generated README for Python SDK ([25bbecc](https://github.com/fw-ai-external/python-sdk/commit/25bbecca2a3623f7890e91b61d0fba0991f360c1))
* Add DPO Job REST API to docs + SDK ([556a15c](https://github.com/fw-ai-external/python-sdk/commit/556a15c268996b230440a7c5983f585e658ba745))
* Add GetBillingSummary to REST API + SDK ([f818671](https://github.com/fw-ai-external/python-sdk/commit/f81867100b13d463c3365994b3765a788ee3821f))
* add secrets REST APIs to docs + SDK ([8f43098](https://github.com/fw-ai-external/python-sdk/commit/8f4309898ae6f0c186500f7022c9921e0f8741c5))
* add shared models deployed_model / deployed_model_ref ([8cee0c5](https://github.com/fw-ai-external/python-sdk/commit/8cee0c5823f2d6717a75513743e6f0268fab995f))
* **api:** api update ([8719875](https://github.com/fw-ai-external/python-sdk/commit/87198753f559f94e6ec4271ea18e89eb5ff0282e))
* **api:** api update ([93d7d7a](https://github.com/fw-ai-external/python-sdk/commit/93d7d7a49ed1d243e5c40f4a012b1f7af635e916))
* **api:** api update ([3b8eb54](https://github.com/fw-ai-external/python-sdk/commit/3b8eb54d48cf18860e9f511b6284f4b80915a59e))
* **api:** api update ([ce0f8d1](https://github.com/fw-ai-external/python-sdk/commit/ce0f8d1d6fa91311307ec25b866502f5b4071c90))
* **api:** api update ([8c7147e](https://github.com/fw-ai-external/python-sdk/commit/8c7147e33cb08df91dad91af93bd58c6a0434d29))
* **api:** manual updates ([e4ff837](https://github.com/fw-ai-external/python-sdk/commit/e4ff837ab72241ab686d71dfe9f7cb31bf3c1398))
* **client:** use aiohttp as default with 1000 connection pool size ([7dc10ac](https://github.com/fw-ai-external/python-sdk/commit/7dc10acc5a66b6f1ea13e03a7f585f1e34f63565))
* Ensure ordering between Docs / SDK is the same ([3aad15c](https://github.com/fw-ai-external/python-sdk/commit/3aad15c5fe2206ccfe9f126cdb2c03cbeb2864c1))
* Export OpenAPI from Text Completion ([271c181](https://github.com/fw-ai-external/python-sdk/commit/271c18114f964f90376e581afca70b8816829b38))
* Generate SDKs from stainless using OpenAPI specs ([1c69ee2](https://github.com/fw-ai-external/python-sdk/commit/1c69ee295a8fa16d734d44960848685ec66cf816))
* Publish Python SDK: 1.0.0-alpha.1 ([7fa189b](https://github.com/fw-ai-external/python-sdk/commit/7fa189b687acc70357b80f8b67aec09c027f33c5))


### Bug Fixes

* compat with Python 3.14 ([f896c0b](https://github.com/fw-ai-external/python-sdk/commit/f896c0b99b0bf48b194b813e74dac19aac4d2d24))
* **compat:** update signatures of `model_dump` and `model_dump_json` for Pydantic v1 ([e7405ba](https://github.com/fw-ai-external/python-sdk/commit/e7405ba9ff2308eddb61f9fcc5e04822f51aa369))
* ensure streams are always closed ([1cb89c3](https://github.com/fw-ai-external/python-sdk/commit/1cb89c3ba17fb255cf1e21a26c8954eded33e4b2))
* properly close aiohttp connector when AsyncFireworks client is garbage collected ([f079210](https://github.com/fw-ai-external/python-sdk/commit/f079210d10d251394cee7f0d2ba5d14550869fa7))
* **tests:** use httpx client in tests for respx_mock compatibility ([62e6f21](https://github.com/fw-ai-external/python-sdk/commit/62e6f21ef0e51b60551c0639600a6c3d07e5e341))


### Chores

* add Python 3.14 classifier and testing ([5436aef](https://github.com/fw-ai-external/python-sdk/commit/5436aefe9f3483f9551a8537da1c9e3c014bbb76))
* **deps:** mypy 1.18.1 has a regression, pin to 1.17 ([695f55f](https://github.com/fw-ai-external/python-sdk/commit/695f55fedacbee84e60f53a0cd001dbc028b8971))
* **package:** drop Python 3.8 support ([76b2ede](https://github.com/fw-ai-external/python-sdk/commit/76b2ede6c409f753f6c70e869198d7512dc0c12a))
* update SDK settings ([b649187](https://github.com/fw-ai-external/python-sdk/commit/b64918770170505b03e37fa1b344d9b1a56839b5))


### Documentation

* **readme:** add documentation for reasoning_content in thinking models ([8de75aa](https://github.com/fw-ai-external/python-sdk/commit/8de75aa9070ca695e0a832177536d387971073d0))
* **readme:** update HTTP client documentation to reflect aiohttp as default for async ([e0591ce](https://github.com/fw-ai-external/python-sdk/commit/e0591ce5d9cbbdad1afd7d2f56191f67137942c1))
